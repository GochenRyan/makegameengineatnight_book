import bpy
import bmesh
import os
import struct

def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):
    def draw(self, context):
        self.layout.label(text=message)
    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

# Get the active mesh
object=bpy.context.object
mesh = object.data

print(mesh.vertices)


    
print("----EXPORT-----------------------------------")

if os.path.exists("export")==False:
    os.mkdir("export")
    
dir_path="export/"+object.name_full

if os.path.exists(dir_path)==False:
    os.mkdir(dir_path)
    
with open(dir_path+"/"+object.name_full+'.mesh', 'wb') as f:
    f.write(struct.pack('H',len(mesh.vertices)))
    for v in mesh.vertices:
        print("---------------")
        print(v)
        print(v.co)
        print(v.index)
        print(v.normal)
        
        f.write(struct.pack('fff',v.co.x,v.co.y,v.co.z))
        f.write(struct.pack('fff',v.normal.x,v.normal.y,v.normal.z))

        

    uv_layer = mesh.uv_layers.active.data
    f.write(struct.pack('H',len(mesh.polygons)))

    for poly in mesh.polygons:
        print("Polygon index: %d, length: %d" % (poly.index, poly.loop_total))
        if poly.loop_total==4:
            ShowMessageBox("Need Triangle","Polygon Error",  'ERROR')
            break
        
        # range is used here to show how the polygons reference loops,
        # for convenience 'poly.loop_indices' can be used instead.
        for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
            vertex_index=mesh.loops[loop_index].vertex_index
            uv=uv_layer[loop_index].uv
            
            print("    Vertex: %d" % vertex_index)
            print("    UV: %r" % uv)
            
            f.write(struct.pack('H',vertex_index))
            f.write(struct.pack('ff',uv.x,uv.y))
            
    f.close()
    
print("----SUCCESS-----------------------------------")